<?php 
define ('DBTYPE', 'SQLite');
define ('DBNAME', 'seosite');