<?php
$conf+=array (
  'duoshuoID' => '',
  'disqusID' => '',
  'sinaAKey' => '',
  'sinaSKey' => '',
  'qiniuAKey' => '5JXR7LPi6dIaB1RchCxZufG8IWfZ0Bp2l6VZsboe',
  'qiniuSKey' => 'psNi2ed5ksUjmaDMwaMqqh0q0u1cVdsnY9FxLBN0',
  'qiniuBucket' => 'seosite',
  'qiniuSync' => '',
  'qiniuUpload' => '1',
  'qiniuDomain' => ' ocxqiuz4y.bkt.clouddn.com',
);?>